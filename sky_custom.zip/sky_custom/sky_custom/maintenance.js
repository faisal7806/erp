get_list_filters() {
		return frappe.db.get_list('maintenance_schedule', {
			fields: ['sales_order_no'],
			filters: { reference_doctype: this.list_view.maintenance_schedule },
			or_filters: [['is_amc', '=', 1], ['workflow_state', '=', 'Approved By Account']]
		}).then((filters) => {
			this.filters =  [];
		});