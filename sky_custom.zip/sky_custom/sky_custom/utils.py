from __future__ import unicode_literals
import frappe
from frappe.model.document import Document
from frappe.utils import flt, has_common





def get_permission_query_conditions_so(user):
	role_to_check = ["Service Engineer","Sales Manager",
			"Sales & Service Engineer","Sales Engineer","Service Manager"]

	if user == "Administrator":
		return "1=1"

	if has_common(role_to_check,frappe.get_roles()):
		return """`tabSales Order`.assign_technical_person_ = '{0}' """.format(user)
	else:
		return """1=1"""